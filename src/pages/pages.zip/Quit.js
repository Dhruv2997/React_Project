import React from 'react';

function Quit() {
  return (
    <div className='products'>
      <h1>Quit</h1>
    </div>
  );
}

export default Quit;